/opt/etl/prd/etl/APP/RPT/U_RELAY42_TX_GEN_RPT/bin> cat RELAY42_GEN_FILE2.pl
#!/usr/bin/perl -w
use Digest::SHA qw(sha256); # hash SHA-256  algorithm
use MIME::Base64;
use strict;
use Crypt::CBC; # AES 256  algorithm
use Config;

#
# $Header: dw_unpack_mscfile.pl,v 1.1 2005/08/29 14:43:25 dwbat Exp $
#
# $Locker: dwbat $
#
# $Log: dw_unpack_mscfile.pl,v $
# Revision 1.1  2005/08/29  14:43:25  14:43:25  dwbat (Data Warehouse Batch Job User (Oracle))
# Initial revision

#Revision 1.1  2004/11/17  19:57:12  19:57:12  dwbat (DW Batch Job Account)
#Initial revision
#
#
#
#$checksum = 0;
my $filename = $ARGV[0];
my $outfile = $ARGV[1];
my $salt = "Relay42#SMC".q(@)."Nov2018"; # hash SHA-256  algorithm
my $passphrase = "SMCRelay42Nov2018";  # AES 256  algorithm

sub encrypt {
  my ($plain_text) = @_;
  my $pbe = Crypt::CBC->new(
     -key => $passphrase,
     -cipher  => 'Crypt::Rijndael',
     -keysize => 128/8,
  );
  my $cipher_text = $pbe->encrypt($plain_text);
  my $encrypted_text = encode_base64($cipher_text);
  return $encrypted_text;
}


open(IN, "< $filename") or die "Can't open file $filename";
open(OUT, "> $outfile") or die "Can't open file $outfile";

while (<IN>) {
#  $checksum++ if /^10/;
#  $checksum-- if /^90/;
#  next if /^[19]0/;
  

##1 Acct_Subr_Num_h hash salt algorithm  for  Acct_Subr_Num_h
##2 Acct_Subr_Num_e encrypt algorithm for  Acct_Subr_Num_e
##3 Acct_Num_h hash salt algorithm  for Acct_Num_h
##4 Acct_Num_e encrypt algorithm for Acct_Num_e
##5 Subr_Num_hs hash salt algorithm  for Subr_Num_h
##6 Subr_Num_h hash algorithm  for Subr_Num_h -- new add on 2019-06-12
##7 Subr_Num_e encrypt algorithm for Subr_Num_e
##8 HKID_BR_h hash salt algorithm  for HKID_BR_h
##9 HKID_BR_e encrypt algorithm for HKID_BR_e
##10 Comm_Email_hs hash salt algorithm  for Comm_Email_h
##11 Comm_Email_h hash algorithm  for Comm_Email_h -- new add on 2019-06-12
##12 Comm_Email_e encrypt algorithm for Comm_Email_e
##13 Comm_Lang
##14 BILL_Email_hs hash salt algorithm  for BILL_Email_h
##15 BILL_Email_h hash algorithm  for BILL_Email_h -- new add on 2019-06-12
##16 BILL_Email_e encrypt algorithm for BILL_Email_e
##17 Customer_Type
##18 Line_Status
##19 Masked_Flg
##20 Payment_Method
##21 PP_Tier
##22 Loginnow_Status
##23 Subr_Plan_Name
##24 Plan_Cat
##25 Max_LD_Expiry_Date
##26 RDDP_Flg
##27 VWE_Flg
##28 Traval_Past_6mths
##29 BLACK_LIST_CUST_WRITHOFF_FLG --new add on 2019-03-12
##30 BLACK_LIST_CUSTOMER_FLG
##31 DM_CONSENT_DERIVED_FLG
##32 REJECT_ALL_COMM_FLG
##33 D_FREEZE_FLG
##34 D_FREEZE_FLG_EMAIL
##35 D_FREEZE_FLG_SMS
##36 D_LIMITED_CONTACT
##37 D_LIMITED_CONTACT_EMAIL
##38 D_LIMITED_CONTACT_SMS
##39 SUPRT_MMS_FLG
##40 EMAIL_INTERNET_STUFF_EMAIL_FLG
##41 EMAIL_INTERNET_STUFF_SMS_FLG
##42 FUN_STUFF_EMAIL_FLG
##43 FUN_STUFF_SMS_FLG
##44 NEWS_FINANCE_INVEST_EMAIL_FLG
##45 NEWS_FINANCE_INVEST_SMS_FLG
##46 SENSITIVE_SUBJECT_EMAIL_FLG
##47 SENSITIVE_SUBJECT_SMS_FLG
##48 SPECIAL_OFFER_EMAIL_FLG
##49 SPECIAL_OFFER_SMS_FLG --new add on 2019-03-12

my ($Acct_Subr_Num_h,$Acct_Subr_Num_e,$Acct_Num_h,$Acct_Num_e,$Subr_Num_hs,$Subr_Num_h,$Subr_Num_e,$HKID_BR_h,$HKID_BR_e,$Comm_Email_hs,$Comm_Email_h,$Comm_Email_e,$Comm_Lang,$BILL_Email_hs,$BILL_Email_h,$BILL_Email_e,$Customer_Type,$Line_Status,$Masked_Flg,$Payment_Method,$PP_Tier,$Loginnow_Status,$Subr_Plan_Name,$Plan_Cat,$Max_LD_Expiry_Date,$RDDP_Flg,$VWE_Flg,$Traval_Past_6mths,$BLACK_LIST_CUST_WRITHOFF_FLG,$BLACK_LIST_CUSTOMER_FLG,$DM_CONSENT_DERIVED_FLG,$REJECT_ALL_COMM_FLG,$D_FREEZE_FLG,$D_FREEZE_FLG_EMAIL,$D_FREEZE_FLG_SMS,$D_LIMITED_CONTACT,$D_LIMITED_CONTACT_EMAIL,$D_LIMITED_CONTACT_SMS,$SUPRT_MMS_FLG,$EMAIL_INTERNET_STUFF_EMAIL_FLG,$EMAIL_INTERNET_STUFF_SMS_FLG,$FUN_STUFF_EMAIL_FLG,$FUN_STUFF_SMS_FLG,$NEWS_FINANCE_INVEST_EMAIL_FLG,$NEWS_FINANCE_INVEST_SMS_FLG,$SENSITIVE_SUBJECT_EMAIL_FLG,$SENSITIVE_SUBJECT_SMS_FLG,$SPECIAL_OFFER_EMAIL_FLG,$SPECIAL_OFFER_SMS_FLG) = split(/\t/,$_);

# encrypt  algorithm in java class from  Johnson Cheung
#$Acct_Subr_Num_e1=`java -classpath "./classes" SmarTone_Secure.Encryptor encrypt "$Acct_Subr_Num_e" SMCRelay42Nov2018 10 315`;chomp ($Acct_Subr_Num_e1);
#$Acct_Num_e1=`java -classpath "./classes" SmarTone_Secure.Encryptor encrypt "$Acct_Num_e" SMCRelay42Nov2018 10 315`;chomp ($Acct_Num_e1);
#$Subr_Num_e1=`java -classpath "./classes" SmarTone_Secure.Encryptor encrypt "$Subr_Num_e" SMCRelay42Nov2018 10 315`;chomp ($Subr_Num_e1);
#$HKID_BR_e1=`java -classpath "./classes" SmarTone_Secure.Encryptor encrypt "$HKID_BR_e" SMCRelay42Nov2018 10 315`;chomp ($HKID_BR_e1);
#$Comm_Email_e1=`java -classpath "./classes" SmarTone_Secure.Encryptor encrypt  "$Comm_Email_e" SMCRelay42Nov2018 10 315`;chomp ($Comm_Email_e1);
#$BILL_Email_e1=`java -classpath "./classes" SmarTone_Secure.Encryptor encrypt "$BILL_Email_e" SMCRelay42Nov2018 10 315`;chomp ($BILL_Email_e1);
my $Acct_Subr_Num_e1= encrypt($Acct_Subr_Num_e);chomp ($Acct_Subr_Num_e1);
my $Acct_Num_e1= encrypt($Acct_Num_e);chomp ($Acct_Num_e1);
my $Subr_Num_e1=encrypt($Subr_Num_e);chomp ($Subr_Num_e1);
my $HKID_BR_e1=encrypt($HKID_BR_e);chomp ($HKID_BR_e1);
my $Comm_Email_e1=encrypt($Comm_Email_e);$Comm_Email_e1 =~ s/\n//; chomp ($Comm_Email_e1);
my $BILL_Email_e1=encrypt($BILL_Email_e);$BILL_Email_e1 =~ s/\n//; chomp ($BILL_Email_e1);

my $Acct_Subr_Num_h1=unpack("H*", sha256($Acct_Subr_Num_h,$salt));chomp ($Acct_Subr_Num_h1);
my $Acct_Num_h1=unpack("H*", sha256($Acct_Num_h,$salt));chomp ($Acct_Num_h1);
my $Subr_Num_h1=unpack("H*", sha256($Subr_Num_hs,$salt));chomp ($Subr_Num_h1);
my $HKID_BR_h1=unpack("H*", sha256($HKID_BR_h,$salt));chomp ($HKID_BR_h1);
my $Comm_Email_h1=unpack("H*", sha256($Comm_Email_hs,$salt));chomp ($Comm_Email_h1);
my $BILL_Email_h1=unpack("H*", sha256($BILL_Email_hs,$salt));chomp ($BILL_Email_h1);

#hash without salt
my $Subr_Num_h2=unpack("H*", sha256($Subr_Num_h));chomp ($Subr_Num_h2);
my $Comm_Email_h2=unpack("H*", sha256($Comm_Email_h));chomp ($Comm_Email_h2);
my $BILL_Email_h2=unpack("H*", sha256($BILL_Email_h));chomp ($BILL_Email_h2);

print OUT  "$Acct_Subr_Num_h1,$Acct_Subr_Num_e1,$Acct_Num_h1,$Acct_Num_e1,$Subr_Num_h1,$Subr_Num_h2,$Subr_Num_e1,$HKID_BR_h1,$HKID_BR_e1,$Comm_Email_h1,$Comm_Email_h2,$Comm_Email_e1,$Comm_Lang,$BILL_Email_h1,$BILL_Email_h2,$BILL_Email_e1,$Customer_Type,$Line_Status,$Masked_Flg,$Payment_Method,$PP_Tier,$Loginnow_Status,$Subr_Plan_Name,$Plan_Cat,$Max_LD_Expiry_Date,$RDDP_Flg,$VWE_Flg,$Traval_Past_6mths,$BLACK_LIST_CUSTOMER_FLG,$BLACK_LIST_CUST_WRITHOFF_FLG,$DM_CONSENT_DERIVED_FLG,$REJECT_ALL_COMM_FLG,$D_FREEZE_FLG,$D_FREEZE_FLG_EMAIL,$D_FREEZE_FLG_SMS,$D_LIMITED_CONTACT,$D_LIMITED_CONTACT_EMAIL,$D_LIMITED_CONTACT_SMS,$SUPRT_MMS_FLG,$EMAIL_INTERNET_STUFF_EMAIL_FLG,$EMAIL_INTERNET_STUFF_SMS_FLG,$FUN_STUFF_EMAIL_FLG,$FUN_STUFF_SMS_FLG,$NEWS_FINANCE_INVEST_EMAIL_FLG,$NEWS_FINANCE_INVEST_SMS_FLG,$SENSITIVE_SUBJECT_EMAIL_FLG,$SENSITIVE_SUBJECT_SMS_FLG,$SPECIAL_OFFER_EMAIL_FLG,$SPECIAL_OFFER_SMS_FLG";



}
close(IN);
close(OUT);

##die "Check Sum Error" if $checksum != 0;

